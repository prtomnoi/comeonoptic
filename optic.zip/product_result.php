<?php
session_start();
include "inc/common.initial.php";

if($_POST['mode'] == 'add'){
    $price = $_POST['price'];
    $price = str_replace(',', '', $price);
    $price = str_replace('$', '', $price);
    $decimalPrice = number_format((float) $price, 2, '.', '');

    $cost = $_POST['cost'];
    $cost = str_replace(',', '', $cost);
    $cost = str_replace('$', '', $cost);
    $decimalCost = number_format((float) $cost, 2, '.', '');

    $con3 = Db::query('INSERT INTO tb_products SET product_category=? , product_type=? 
    , product_barcode=? , product_number=?, product_model=?, product_cost=?
    , product_price=?, product_amount=?, product_lot=?',$_POST['category'],$_POST['type'],$_POST['code']
    ,$_POST['number'],$_POST['name'],$decimalCost,$decimalPrice,$_POST['amount'],$_POST['date_lot']);

    header("Location: products");
}



if($_POST['mode'] == 'mo'){

    
    $price = $_POST['price'];
    $price = str_replace(',', '', $price);
    $price = str_replace('$', '', $price);
    $decimalPrice = number_format((float) $price, 2, '.', '');

    $cost = $_POST['cost'];
    $cost = str_replace(',', '', $cost);
    $cost = str_replace('$', '', $cost);
    $decimalCost = number_format((float) $cost, 2, '.', '');

    $con3 = Db::query('UPDATE tb_products SET product_category=? , product_type=? 
    , product_barcode=? , product_number=?, product_model=?, product_cost=?
    , product_price=?, product_amount=?, product_lot=? WHERE product_id=?',$_POST['category'],$_POST['type'],$_POST['code']
    ,$_POST['number'],$_POST['name'],$decimalCost,$decimalPrice,$_POST['amount'],$_POST['date_lot'],$_POST['id']);

    header("Location: products");
}

if($_GET['getId']){
   
    $con = Db::queryOne('SELECT * FROM tb_category WHERE category_id=?',$_GET['getId']);

    header('Content-type: application/json; charset=utf-8');
    echo json_encode($con);

}

if($_GET['del']){
    $con = Db::query('UPDATE tb_category SET deleted_at = NOW() WHERE category_id=?',$_GET['del']);
}




?>

