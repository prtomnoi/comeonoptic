<?php
session_start();
include "inc/common.initial.php";

if($_POST['mode'] == 'add'){

    $password =  SHA1($_POST['password']."A^jblgfdr#Z");
    
    $con3 = Db::query('INSERT INTO tb_member SET member_branch=? , member_name=? , member_code=? 
    ,member_phone=? ,member_username=? ,member_password=? , member_role = ? ',$_POST['branch'],$_POST['name'],$_POST['code'],$_POST['phone'],$_POST['username'],$password ,2);

    header("Location: employee");
}



if($_POST['mode'] == 'mo'){

    if($_POST['password'] == ""){
        $con3 = Db::query('UPDATE tb_member SET member_branch=? , member_name=? , member_code=? ,member_phone=? ,member_username=? WHERE member_id = ?
        ',$_POST['branch'],$_POST['name'],$_POST['code'],$_POST['phone'],$_POST['username'],$_POST['id']);
    }else{
        $password =  SHA1($_POST['password']."A^jblgfdr#Z");
        $con3 = Db::query('UPDATE tb_member SET member_branch=? , member_name=? , member_code=? ,member_phone=? ,member_username=? , member_password=? WHERE member_id = ?
        ',$_POST['branch'],$_POST['name'],$_POST['code'],$_POST['phone'],$_POST['username'],$password,$_POST['id']);
    }

 

    header("Location: employee");
}

if($_GET['getId']){
   
    $con = Db::queryOne('SELECT * FROM tb_member WHERE member_id=?',$_GET['getId']);

    header('Content-type: application/json; charset=utf-8');
    echo json_encode($con);

}

if($_GET['del']){
    $con = Db::query('UPDATE tb_member SET member_status = 1 WHERE member_id=?',$_GET['del']);
}




?>

