<?php
// include_once('Db.php');
// Db::connect('10.17.32.3','thaiplan','thaiplanusr','Gb_aaQR8DGb9/({*');
// date_default_timezone_set("Asia/Bangkok");
include_once('Db.php');
Db::connect('localhost','comeonoptic','root','');
date_default_timezone_set("Asia/Bangkok");
?>