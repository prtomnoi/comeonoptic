<html>
	<meta charset="UTF-8">
	<body>
			<center	><form action="save_product.php" method="POST" enctype="multipart/form-data">
			poid<input type="text" name="t1"><br>
			topic<input type="text" name="t7"><br>
			proname<input type="text" name="t2"><br>
			price<input type="text" name="t3"><br>
			sale<input type="text" name="t4"><br>
			detail<input type="text" name="t5"><br>
			count<input type="text" name="t6"><br>
			pic<input type="file" name="pic1"><br>
			<input type="hidden" name="mode" value="add"><br>
		<button type="submit" >SAVE</button>
		</form>
	</body>
</html>